package com.example.cricket;

import java.awt.print.PageFormat;
import java.awt.print.Pageable;
import java.awt.print.Printable;

public class PageResult implements Pageable {
	
	 public static final long DEFAULT_OFFSET = 0;
	    public static final int DEFAULT_MAX_NO_OF_ROWS = 100;
	    private int offset;
	    private int limit;
	    private long totalElements;
//	    private List<T> elements;
	    
	    public PageResult(int i, int j) {
	    	 this.offset = offset;
		        this.limit = limit;
		}

		
	@Override
	public int getNumberOfPages() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public PageFormat getPageFormat(int pageIndex) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Printable getPrintable(int pageIndex) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		return null;
	}

}
