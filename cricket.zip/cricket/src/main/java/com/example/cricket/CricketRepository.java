package com.example.cricket;

import java.awt.print.Pageable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface CricketRepository extends JpaRepository<Cricket, Long>{
	
	@Query(value="select * from cricket u limit 4",countQuery = "SELECT count(*) FROM cricket", nativeQuery = true)
	List<Cricket> findPlayers();

	@Query(value="select * from cricket u",countQuery = "SELECT count(*) FROM cricket", nativeQuery = true)
	List<Cricket> countPlayers();

	
	@Query(value="select * from cricket u OFFSET ?1 limit 4",countQuery = "SELECT count(*) FROM cricket", nativeQuery = true)
	List<Cricket> findBypagination(Long id);
	
//	@Query("DELETE u FROM Cricket u WHERE u.id=?1")
//	List<Cricket> deleteUser(Long id);



}

