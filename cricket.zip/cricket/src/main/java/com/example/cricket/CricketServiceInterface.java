package com.example.cricket;

import java.util.List;
import java.util.Optional;



public interface CricketServiceInterface {
	List<Cricket> findPlayers();
	void deleteUser(Long id);
	Optional<Cricket> viewUser(Long id);
	List<Cricket> save(Cricket cricket);
	List<Cricket> getPaginationPlayers(Long id);
	List<Cricket> countPlayers();
}
