package com.example.cricket;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CricketController{
	
	@Autowired(required=false)
	CricketServiceInterface cricketinterface;
	
	@GetMapping("/")
	public List<Cricket> getPlayers() {
		return cricketinterface.findPlayers();
	}
	
	@GetMapping("/list/{id}")
	public List<Cricket> getPaginationPlayers(@PathVariable long id) {
		Long page_count = id*4;  
		return cricketinterface.getPaginationPlayers(page_count);
	}
	
	@GetMapping("/list/")
	public int getPlayerCounts() {
		
		return cricketinterface.countPlayers().size();
	}
	
	
	@GetMapping("/alllist/")
	public int getAllPlayer() {
		
		return cricketinterface.countPlayers().size();
	}
	
	@GetMapping("/view/{id}")
	public Optional<Cricket> getPlayersId(@PathVariable long id) {
		return cricketinterface.viewUser(id);
	}
	
	
	@PostMapping("/add")
	public void getData(@RequestBody Cricket test) {
		 cricketinterface.save(test);
	}
	
	@GetMapping("/delete/{id}")
	public List<Cricket> deleteData(@PathVariable long id) {
		 cricketinterface.deleteUser(id);
		 return cricketinterface.findPlayers();
	}
}
