package com.example.cricket;

import java.awt.print.Pageable;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class CricketService implements CricketServiceInterface{
	
	@Autowired
	CricketRepository cricketRepository;

	@Override
	public List<Cricket> findPlayers() {
		// TODO Auto-generated method stub
//		return cricketRepository.findPlayers(Pageable pageable);
		
//		Pageable pageable = pageable.;
		return cricketRepository.findPlayers();
	}

	@Override
	public void deleteUser(Long id) {
		// TODO Auto-generated method stub
		 cricketRepository.deleteById(id);
	}

	@Override
	public Optional<Cricket> viewUser(Long id) {
		// TODO Auto-generated method stub
		return cricketRepository.findById(id);
	}

	@Override
	public List<Cricket> save(Cricket cricket) {
		// TODO Auto-generated method stub
		cricketRepository.save(cricket);
		return cricketRepository.findAll();
	}

	@Override
	public List<Cricket> getPaginationPlayers(Long id) {
		// TODO Auto-generated method stub
		return cricketRepository.findBypagination(id);
	}
	
	@Override
	public List<Cricket> countPlayers() {
		// TODO Auto-generated method stub
		return cricketRepository.countPlayers();
	}

	

}
